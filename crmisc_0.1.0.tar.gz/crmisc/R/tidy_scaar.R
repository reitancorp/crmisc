#' @description  Convenience function for tidy SCAAR data formatting
#' @title Tidy SCAAR data
#' @param x a data frame with data from the SCAAR data base. The original variable names should not be altered.
#' @return A tibble containing tidy SCAAR data.
tidy_scaar <- function(x) {
return('Function not ready to function')
}
